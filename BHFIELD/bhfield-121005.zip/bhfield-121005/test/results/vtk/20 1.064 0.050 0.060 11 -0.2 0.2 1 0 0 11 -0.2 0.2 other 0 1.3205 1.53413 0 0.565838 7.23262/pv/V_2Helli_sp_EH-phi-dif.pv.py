# pv_template: 2d_warp.pv.py
# paraview script; created by paraview - tools - start trace, then hand-edited
# scalar data on 2D plane -> warp by scalar; show surface
# 3-vector data on 2D plane -> warp by magnitude; show surface + glyph

# Usage:
# (a) commmand prompt - pvpython ...py -> not interactive
# (b) paraview - tools - python shell - run script -> interactive GUI

# paraview bug: .Scale does not work!
# To Do: fixed scale

# args: must be strings
base_dir = r"C:\Windoc\Programming\Fortran\Scatter\src\121002-bhfield-distro\bhfield-121002\test\20 1.064 0.050 0.060 11 -0.2 0.2 1 0 0 11 -0.2 0.2 other 0 1.3205 1.53413 0 0.565838 7.23262\vtk"
fn_data = r"V_2Helli_sp.vtk"
fn_image = r"V_2Helli_sp_EH-phi-dif.png"
data_name = r"EH-phi-dif"
legends = r"x;y;z"
glyph_type_vector = "Arrow" # "Arrow", "Cone"
glyph_sfactor = r"0.1"
elevation = r"30"
azimuth = r"-115"

import sys, os.path

pn_data  = os.path.join(base_dir, fn_data)
if len(fn_image) > 0: pn_image = os.path.join(base_dir, fn_image)

try: paraview.simple
except: from paraview.simple import *
paraview.simple._DisableFirstRenderCameraReset()

# read data & info
reader = OpenDataFile(pn_data)
reader.UpdatePipeline() # needed!
di = reader.GetDataInformation().DataInformation
bo = di.GetBounds() # (-0.2, 0.2, 0.0, 0.0, -0.2, 0.2)
ex = di.GetExtent() # (0, 10, 0, 0, 0, 10)
# di.GetDataSetTypeAsString() # 'vtkImageData'
# di.GetDataClassName() # 'vtkImageData'
# di.GetNumberOfPoints() # 121L

# (nx, ny, nz) -> set warp direction
nx, ny, nz = map(lambda x: int(x) + 1, (ex[1] - ex[0], ex[3] - ex[2], ex[5] - ex[4]))

if nz == 1: # xy-plane
	iwarp = 2 # warp to z
	sys.stderr.write("xy grid - warp scalar to z\n")
elif ny == 1: # xz-plane
	iwarp = 1 # warp to y
	sys.stderr.write("xz grid - warp scalar to y\n")
elif nx == 1: # yz-plane
	iwarp = 0 # warp to x
	sys.stderr.write("yz grid - warp scalar to x\n")
else:
	raise ValueError

warp_v = [0.0, 0.0, 0.0]
warp_v[iwarp] = 1.0

# use max axis length for scaling
grid_span = max(bo[1] - bo[0], bo[3] - bo[2], bo[5] - bo[4])
assert grid_span > 0, "Error: grid span = %g" % grid_span

pd = reader.PointData
# data_name = pd.keys()[data_idx] # ['abs[Ec]^2']
data = pd[data_name]
dim = data.GetNumberOfComponents()

if dim == 1: # scalar
	s_name = data_name
	s_range = data.GetRange() # (0, 0.2)
	sys.stderr.write("scalar data: %s\n" % s_name)
elif dim == 3: # vector
	v_name = data_name

	# add vector magnitude as scalar
	Calculator1 = Calculator()
	Calculator1.AttributeMode = 'point_data'
	Calculator1.Function = 'mag(%s)' % v_name # E-major
	s_name = 'vmag_%s' % v_name
	Calculator1.ResultArrayName = s_name

	s_range = Calculator1.PointData[s_name].GetRange() # (0, 0.2)
	sys.stderr.write("vector data: %s\n" % v_name)
else:
	raise ValueError, "Error: unsupported data dim (%d)" % dim

s_span = s_range[1] - s_range[0]
# assert s_span > 0, "s_range %s" % str(s_range)
if s_span <= 0:
	raise ValueError, "Error: s_span = %g" % s_span
	# s_span = 1.0 # avoid zero division
	# sys.stderr.write("Error: s_span = %g\n" % s_span)
	# sys.exit(0) # pvpython freeze NG

# filter: threshold; we need this to get warpscalar work (silly)
# http://www.mail-archive.com/paraview@paraview.org/msg12920.html
Threshold1 = Threshold()
Threshold1.Scalars = ['POINTS', s_name]
Threshold1.ThresholdRange = s_range

# show lut legend
lut = GetLookupTableForArray(s_name, 1, NanColor=[0.5, 0.5, 0.5], 
RGBPoints=[s_range[0], 0.0, 0.0, 1.0, s_range[1], 1.0, 0.0, 0.0], ColorSpace='HSV')
sbrep = CreateScalarBar(Title=s_name, LabelFontSize=12, Enabled=1, TitleFontSize=12)
sbrep.LookupTable = lut
GetRenderView().Representations.append(sbrep)

# filter: warp by scalar
WarpByScalar1 = WarpByScalar()
WarpByScalar1.Scalars = ['POINTS', s_name]
WarpByScalar1.ScaleFactor = grid_span / s_span
WarpByScalar1.Normal = warp_v
wsrep = Show()
wsrep.ColorArrayName = s_name
wsrep.LookupTable = lut
# wsrep.Scale = [1.0, 0.2, 1.0]

datasrc = GetActiveSource()

if dim == 3:
	# add glyph; glyph masking buggy -> need MaskPoints -> buggy!  pvpython freeze NG
	# SetActiveSource(datasrc)
	# MaskPoints1 = MaskPoints(datasrc)
	# MaskPoints1.RandomSampling = 1
	# masksrc = MaskPoints1

	Glyph1 = Glyph(datasrc, GlyphType=glyph_type_vector, GlyphTransform="Transform2")
	Glyph1.Scalars = ['POINTS', s_name]
	Glyph1.Vectors = ['POINTS', v_name]
	Glyph1.SetScaleFactor = float(glyph_sfactor) * grid_span / s_span
	Glyph1.GlyphType.TipResolution = 10
	Glyph1.GlyphType.ShaftResolution = 10
	Glyph1.MaskPoints = 0 # paraview bug
	glrep = Show()
	glrep.ColorArrayName = s_name
	glrep.LookupTable = lut
	# glrep.Scale = [1.0, 0.2, 1.0]

	# make surface transparent
	wsdp = GetDisplayProperties(WarpByScalar1)
	wsdp.Opacity = 0.2

# filter: outline + axes
# xyztitles = ['x-axis', 'y-axis', 'z-axis']
# xyztitles[iwarp] = s_name # label can be too small or too large
xyztitles = legends.split(';') # "x;y;z" -> ["x", "y", "z"]
assert len(xyztitles) == 3, "error: not 3 legends: %s" % str(xyztitles)
Outline1 = Outline(datasrc)
olrep = Show()
olrep.CubeAxesVisibility = 1 # show ticks
olrep.CubeAxesFlyMode = 'Outer Edges'
olrep.CubeAxesXTitle = xyztitles[0]
olrep.CubeAxesYTitle = xyztitles[1]
olrep.CubeAxesZTitle = xyztitles[2]

# nice view
view = GetRenderView()
view.CameraViewUp = warp_v
camera = GetActiveCamera()

# paraview bug: to avoid "Resetting view-up since view plane normal is parallel"
# camera.OrthogonalizeViewUp()

# camera.Elevation(30)
camera.Elevation(float(elevation))

# camera.Azimuth(-15)  # +x right, +y up, +z deep
# camera.Azimuth(-115) # +x deep, +y up, +z right
camera.Azimuth(float(azimuth))

ResetCamera() # fit to window

Render()

if len(fn_image) > 0: # render high resolution image
	orig_size = view.ViewSize[:] # [685, 519]; needs deep copy!
	view.ViewSize = [1200, int(1200.0 * orig_size[1] / orig_size[0])]
	Render()
	WriteImage(pn_image)
	view.ViewSize = orig_size
	Render()

# end of file
