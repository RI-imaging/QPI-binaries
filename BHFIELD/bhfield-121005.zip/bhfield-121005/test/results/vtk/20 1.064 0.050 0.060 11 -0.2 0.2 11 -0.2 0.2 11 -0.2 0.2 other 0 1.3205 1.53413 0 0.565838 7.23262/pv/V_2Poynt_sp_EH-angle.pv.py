# pv_template: 3d.pv.py
# paraview script; created by paraview - tools - start trace, then hand-edited
# scalar data on 3D lattice -> show volume?
# 3-vector data on 3D lattice -> show glyph; magnitude as volume?

# Usage:
# (a) commmand prompt - pvpython ...py -> not interactive
# (b) paraview - tools - python shell - run script -> interactive GUI

# cf. To trace in more detail: paraview manual p.195
# <start trace>
# from paraview import smtrace
# smtrace.start_trace(CaptureAllProperties=True)
# <stop trace>

# paraview bug: .Scale does not work!

# args: must be strings
base_dir = r"C:\bhfield-121002\test\20 1.064 0.050 0.060 11 -0.2 0.2 11 -0.2 0.2 11 -0.2 0.2 other 0 1.3205 1.53413 0 0.565838 7.23262\vtk"
fn_data = r"V_2Poynt_sp.vtk"
fn_image = r"V_2Poynt_sp_EH-angle.png"
data_name = r"EH-angle"
legends = r"x;y;z"
n_contour = "10"
glyph_type_scalar = "Sphere" # "Sphere", "Box", "Cylinder"
glyph_type_vector = "Arrow" # "Arrow", "Cone"
glyph_sfactor = r"0.1"
elevation = r"30"
azimuth = r"-115"

import sys, os.path

pn_data  = os.path.join(base_dir, fn_data)
if len(fn_image) > 0: pn_image = os.path.join(base_dir, fn_image)

try: paraview.simple
except: from paraview.simple import *
paraview.simple._DisableFirstRenderCameraReset()

# read data & info
reader = OpenDataFile(pn_data)
reader.UpdatePipeline() # needed!
di = reader.GetDataInformation().DataInformation
bo = di.GetBounds() # (-0.2, 0.2, 0.0, 0.0, -0.2, 0.2)
ex = di.GetExtent() # (0, 10, 0, 0, 0, 10)
# di.GetDataSetTypeAsString() # 'vtkImageData'
# di.GetDataClassName() # 'vtkImageData'
# di.GetNumberOfPoints() # 121L

# (nx, ny, nz) -> set warp direction
nx, ny, nz = map(lambda x: int(x) + 1, (ex[1] - ex[0], ex[3] - ex[2], ex[5] - ex[4]))

if nz == 1 or ny == 1 or nx == 1: raise ValueError

# use max axis length for scaling
grid_span = max(bo[1] - bo[0], bo[3] - bo[2], bo[5] - bo[4])
assert grid_span > 0, "Error: grid span = %g" % grid_span

pd = reader.PointData
# data_name = pd.keys()[data_idx] # ['abs[Ec]^2']
data = pd[data_name]
dim = data.GetNumberOfComponents()

if dim == 1: # scalar
	s_name = data_name
	s_range = data.GetRange() # (0, 0.2)
	sys.stderr.write("scalar data: %s\n" % s_name)
elif dim == 3: # vector
	v_name = data_name

	# add vector magnitude as scalar
	Calculator1 = Calculator()
	Calculator1.AttributeMode = 'point_data'
	Calculator1.Function = 'mag(%s)' % v_name # E-major
	s_name = 'vmag_%s' % v_name
	Calculator1.ResultArrayName = s_name
	s_range = Calculator1.PointData[s_name].GetRange() # (0, 0.2)
	sys.stderr.write("vector data: %s\n" % v_name)
else:
	raise ValueError, "Error: unsupported data dim (%d)" % dim

s_span = s_range[1] - s_range[0]
# assert s_span > 0, "s_range %s" % str(s_range)
if s_span <= 0:
	raise ValueError, "Error: s_span = %g" % s_span
	# s_span = 1.0 # avoid zero division
	# sys.stderr.write("Error: s_span = %g\n" % s_span)
	# sys.exit(0) # pvpython freeze NG

# filter: threshold; we need this to get warpscalar work (silly)
# http://www.mail-archive.com/paraview@paraview.org/msg12920.html
# we also need this to make calculator's result available for lut (silly)
Threshold1 = Threshold()
Threshold1.Scalars = ['POINTS', s_name]
Threshold1.ThresholdRange = s_range

# show lut legend
lut = GetLookupTableForArray(s_name, 1, NanColor=[0.5, 0.5, 0.5], 
RGBPoints=[s_range[0], 0.0, 0.0, 1.0, s_range[1], 1.0, 0.0, 0.0], ColorSpace='HSV')
sbrep = CreateScalarBar(Title=s_name, LabelFontSize=12, Enabled=1, TitleFontSize=12)
sbrep.LookupTable = lut
GetRenderView().Representations.append(sbrep)

datasrc = GetActiveSource()


# filter: Contour
Contour1 = Contour(datasrc)
Contour1.ContourBy = ['POINTS', s_name]
n_contour = int(n_contour)
Contour1.Isosurfaces = [s_range[0] + i * s_span / (n_contour - 1) for i in range(n_contour)] # need this
# Contour1.UpdatePipeline()

ctrep = Show()
ctrep.LookupTable = lut
ctrep.ColorArrayName = s_name

# if mag_S unavailable:
# ctrep.ColorArrayName = v_name
# lut.VectorMode = 'Magnitude'

# ctrep.Scale = [1.0, 0.2, 1.0]


# filter: IsoVolume
IsoVolume1 = IsoVolume(datasrc)
IsoVolume1.InputScalars = ['POINTS', s_name]
IsoVolume1.ThresholdRange = [s_range[0], s_range[1]] # need this
# IsoVolume1.UpdatePipeline()
ivrep = Show()
ivrep.Opacity = 0.2
ivrep.LookupTable = lut
ivrep.ColorArrayName = s_name


# filter: MaskPoints for Glyph(s)
# glyph masking buggy -> need MaskPoints -> buggy!  pvpython freeze NG
# MaskPoints1 = MaskPoints(datasrc)
# MaskPoints1.RandomSampling = 1
# masksrc = MaskPoints1

# filter: Glyph (sphere) for scalar
Glyph1 = Glyph(datasrc, GlyphType=glyph_type_scalar, GlyphTransform="Transform2")
Glyph1.Scalars = ['POINTS', s_name]
# Glyph1.SetScaleFactor = 0.1 / s_range[1]
Glyph1.SetScaleFactor = float(glyph_sfactor) * grid_span / s_span
Glyph1.ScaleMode = 'scalar'
Glyph1.MaskPoints = 0 # paraview bug
Glyph1.UpdatePipeline()
glrep = Show()
glrep.LookupTable = lut
glrep.ColorArrayName = s_name

# rep = GetDisplayProperties(Glyph1)
if dim == 3: glrep.Visibility = 0 # hide for vector


if dim == 3:
	# filter: Glyph (arrow) for vector

	Glyph3 = Glyph(datasrc, GlyphType=glyph_type_vector, GlyphTransform="Transform2")
	Glyph3.Scalars = ['POINTS', s_name]
	Glyph3.Vectors = ['POINTS', v_name]
	# Glyph3.SetScaleFactor = 0.1 / s_range[1]
	Glyph3.SetScaleFactor = float(glyph_sfactor) * grid_span / s_span
	Glyph3.ScaleMode = 'vector'
	Glyph3.MaskPoints = 0 # paraview bug
	# Glyph3.GlyphType.TipResolution = 10
	# Glyph3.GlyphType.ShaftResolution = 10
	Glyph3.UpdatePipeline()
	glrep = Show()
	glrep.LookupTable = lut
	glrep.ColorArrayName = s_name
	# glrep.Scale = [1.0, 0.2, 1.0]

	""" To Do ?
	# filter: StreamTracer
	StreamTracer1 = StreamTracer(datasrc, SeedType="Point Source")
	StreamTracer1.SeedType.Center = [0.0, 0.0, 2.5]
	StreamTracer1.SeedType.Radius = 0.1
	StreamTracer1.Vectors = ['POINTS', v_name]
	# StreamTracer1.SeedType.NumberOfPoints = 100
	# active_objects.source.SMProxy.InvokeEvent('UserEvent', 'ShowWidget')
	# StreamTracer1.TerminalSpeed = 1e-12
	# StreamTracer1.MaximumError = 1e-06
	"""

# filter: outline + axes
# xyztitles = ['x-axis', 'y-axis', 'z-axis']
# xyztitles[iwarp] = s_name # label can be too small or too large
xyztitles = legends.split(';') # "x;y;z" -> ["x", "y", "z"]
assert len(xyztitles) == 3, "error: not 3 legends: %s" % str(xyztitles)
Outline1 = Outline(datasrc)
olrep = Show()
olrep.CubeAxesVisibility = 1 # show ticks
olrep.CubeAxesFlyMode = 'Outer Edges'
olrep.CubeAxesXTitle = xyztitles[0]
olrep.CubeAxesYTitle = xyztitles[1]
olrep.CubeAxesZTitle = xyztitles[2]

# nice view
view = GetRenderView()
view.CameraViewUp = [0.0, 1.0, 0.0] # y up
camera = GetActiveCamera()

# paraview bug: to avoid "Resetting view-up since view plane normal is parallel"
# camera.OrthogonalizeViewUp()

# camera.Elevation(30)
camera.Elevation(float(elevation))

# camera.Azimuth(-15)  # +x right, +y up, +z deep
# camera.Azimuth(-115) # +x deep, +y up, +z right
camera.Azimuth(float(azimuth))

ResetCamera() # fit to window

Render()

if len(fn_image) > 0: # render high resolution image
	orig_size = view.ViewSize[:] # [685, 519]; needs deep copy!
	view.ViewSize = [1200, int(1200.0 * orig_size[1] / orig_size[0])]
	Render()
	WriteImage(pn_image)
	view.ViewSize = orig_size
	Render()

# end of file
