# # -*- coding: cp932 -*-
# my utils

import sys, re, string, os, os.path

def flatlist(L):
	"""Flatten a nested list into a simple (unnested) list."""
	items = []
	for item in L:
		if (isinstance(item, list) or isinstance(item, tuple) 
		or isinstance(item, dict)):
			items.extend(flatlist(item))
		else:
			items.append(item)
	return items

def read_tokens(fname, dirname = "", sep = None, skipcomment = True):
	path = os.path.join(dirname, fname)
	fin = open(path, "r")
	# lines = map(string.strip, fin.readlines()) # remove white-sp
	lines = map(lambda s: string.rstrip(s, "\n"), fin.readlines()) # remove \n
	fin.close()

	lines = [line.replace("1.#QOe+000", "0") for line in lines] # iad weird

	lines = map(lambda s: s.split('#')[0], lines) # remove trailing # ...

	lines = filter(lambda s: re.search(r"[^ \t]", s), lines) # not blank line
	if skipcomment:
		# lines = filter(lambda s: re.search(r"^[^#]", s), lines)
		lines = filter(lambda s: re.search(r"^\s*[0-9\+\-\.]", s), lines) # top = numbers
		lines = filter(lambda s: s[:2] != "++", lines) # remove ocean "+++++++..."
	# tokens = [string.split(s) for s in lines] # white-space
	# tokens = [string.split(s, "\t") for s in lines] # tab-separated
	tokens = [string.split(s, sep) for s in lines] # default white-space
	return tokens # [[tok1, tok2, ...], ...]

def read_data(fname, dirname = "", sep = None, skipcomment = True, numpyarray = False):
	tokens = read_tokens(fname, dirname, sep, skipcomment)
	# replace blank data "" -> "0"
	data = [map(lambda s: float(re.sub("^$", "0", s)), line) for line in tokens]

	# data = array(data, Float) # Numeric (list must be ints/floats)
	# data = array(data, dtype=float) # numpy forces type = numpy.float64
	if numpyarray:
		import numpy as N
		data = N.array(data, dtype=object) # numpy bug workaround: type = float
	return data # [[x, y, ...], ...]

def find_files(key, dirname = ".", isregex = False): # unused but looks good
	"""Find files"""
	if not isregex:
		dir_in_key = os.path.dirname(key) # if key has dir, attach it in results
		dirname, key = os.path.split(os.path.join(dirname, key)) # in case key contains dir
	else:
		dir_in_key = ""
	files = [f for f in os.listdir(dirname) if os.path.isfile(
	os.path.join(dirname, f))] # isfile() needs path
	# files = filter(lambda s: os.path.isfile(os.path.join(dirname, s), 
	# os.listdir(dirname))
	if key == "": # return all files
		ans = files
	else:
		if not isregex: # simple string, possibly globbing *. or *.*
			key = "^" + re.sub(r"\\\*", r".*", re.escape(key)) + "$"
			# *.bmp -> .*\.bmp
		# reobj = re.compile("^" + string.lower(key) + "$") # case insensitive
		# ans = filter(lambda s: reobj.search(string.lower(s)), files)
		reobj = re.compile(key)
		ans = filter(lambda s: reobj.search(s), files)
	ans = map(lambda s: os.path.join(dir_in_key, s), ans)
	ans.sort()
	return ans # file name (or path name if key has dir) list (sorted)

def find_all_files(key, dirname = ".", isregex = False): # subdir too, unused
	ans = []
	for root, dirs, files in os.walk(dirname):
		files = find_files(key, root, isregex)
		for f in files:
			fpath = os.path.join(root, f)
			ans.append(fpath)
	return ans # path name list

def confirm_mkdir(dirname):
	if dirname is None or len(dirname) == 0: return
	if not os.path.isdir(dirname):
		os.makedirs(dirname) # recursive
	return

def confirm_open(outfname, dirname = "."): # return output file object
	maxfname = 254 # sure?
	confirm_mkdir(dirname)
	outfname = outfname[:maxfname] # truncate if too long
	path = os.path.join(dirname, outfname)
	if os.path.exists(path):
		s = raw_input("%s exists; overwrite (y/n)? [y] " % outfname)
		if s == 'n' or s == 'N':
			outfname = raw_input("new output file name? ")
			path = os.path.join(dirname, outfname)
	f = open(path, 'w')
	return f

def timestr():
	import time
	# return time.strftime("%Y-%m-%d-%H-%M-%S")
	return time.strftime("%y%m%d%H%M%S")


if __name__ == "__main__":

	print dir()

# end of file

