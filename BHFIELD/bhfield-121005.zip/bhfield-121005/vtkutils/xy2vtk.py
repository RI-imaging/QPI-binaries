#!/usr/bin/python
# # -*- coding: cp932 -*-
# convert a set of xydata to mayavi or paraview vtk 3D: general
# python xy2vtk.py a*.dat [b*.dat ..] out.vtk

# requires: pyvtk
# to do: use tvtk?

import os, sys, math
import numpy as N # NG; try not to use it
import pyvtk

def fields2vtk(points, origins, spacings, fields, names, outfbody, comment = None, 
add_vnorm = False):
	"""Put scalar & vector fields onto xy- or xyz-StructuredPoints in a VTK file.  
	points, origins, spacings = 2- or 3-tuples
	fields = list of s-fields and/or v-fields
	s-field = (z1, z2, ...)
	v-field = ((Vx1, Vy1, Vz1), (Vx2, Vy2, Vz2), ...); list of 3-tuples
	runs as x first; z(xy=00), z(xy=10), ... or z(xyz=000), z(xyz=100), ...
	names = list of field names
	outfbody = string or None (not saved to a file)
	return vtkdata
	To Do: data limit check not done here but done in xyz2vtk - rangecheck; move here?
	"""

	# x, y must be regular mesh (no check)
	# nx, ny = zarray.shape
	if len(points) == 2: # xy plane -> add z = 0 for 3D plane
		points = tuple(points) + (1,)
		origins = tuple(origins) + (0.0,)
		spacings = tuple(spacings) + (1.0,) # must be positive
	sys.stderr.write("Fields -> on (%d x %d x %d) grids\n" % points)

	pdata = []
	for (fld, nam) in zip(fields, names):
		if not (isinstance(fld[0], list) or isinstance(fld[0], tuple)):
			pdata.append(pyvtk.Scalars(fld, name=nam))
			sys.stderr.write("Scalar field = %s\n" % nam)
		elif len(fld[0]) == 3:
			pdata.append(pyvtk.Vectors(fld, name=nam))
			sys.stderr.write("Vector field = %s\n" % nam)
			if add_vnorm:
				vnorms = []
				for v in fld:
					vnorm = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
					vnorms.append(vnorm)
				nam2 = nam + "-norm"
				pdata.append(pyvtk.Scalars(vnorms, name=nam2)) # add norm field
				sys.stderr.write("Scalar field = %s\n" % nam2)
		else:
			assert False, "xy2vtk - fields2vtk: ndim(%d) != 1 or 3 unsupported" % \
			len(fld[0])

	point_data = pyvtk.PointData(*pdata) # list -> args

	# grid(nx*ny*1 StructuredPoints) = xy plane, scalar data = z
	# needs filter WarpScalar to convert to 3D carpet
	# mayavi warpscalar outputs polydata; 
	# NG for further processing (gridplane etc)
	# grid ("dataset") = StructuredPoints(dimensions, origin, spacing)

	grid = pyvtk.StructuredPoints(points, origins, spacings)
	if comment:
		data = pyvtk.VtkData(grid, comment, point_data)
	else:
		data = pyvtk.VtkData(grid, point_data)

	if outfbody:
		outfbody, ext = os.path.splitext(outfbody) # drop ext anyway
		outfname = outfbody + "_sp.vtk"
		data.tofile(outfname)
	return data

def zarray2vtk(zarray, xyorigin, xyspacing, outfbody, comment = None, 
launch_browser = False, structured_grid_out = False):
	"""Dump zarray[nx, ny] onto xy-StructuredPoints in a VTK file.  
	zarray = numpy array (nx*ny)
	xyorigin, xyspacing = 2-tuples"""

	outfbody, ext = os.path.splitext(outfbody) # drop ext anyway

	# x, y must be regular mesh (no check)
	nx, ny = zarray.shape
	points = (nx, ny, 1)
	origin = (xyorigin[0], xyorigin[1], 0.0)
	spacing = (xyspacing[0], xyspacing[1], 1.0) # must be positive

	# Flatten the 2D array data as per VTK's requirements.
	# NG: point_data = pyvtk.PointData(pyvtk.Scalars(z.flat))
	z1 = N.reshape(N.transpose(zarray), (-1,))
	point_data = pyvtk.PointData(pyvtk.Scalars(z1, name=comment))

	# case 1: grid(nx*ny*1 StructuredPoints) = xy plane, scalar data = z
	# needs filter WarpScalar to convert to 3D carpet
	# mayavi warpscalar outputs polydata; 
	# NG for further processing (gridplane etc)
	# grid ("dataset") = StructuredPoints(dimensions, origin, spacing)

	grid = pyvtk.StructuredPoints(points, origin, spacing)
	if comment:
		data = pyvtk.VtkData(grid, comment, point_data)
	else:
		data = pyvtk.VtkData(grid, point_data)

	outfname = outfbody + "_sp.vtk"
	data.tofile(outfname)

	if launch_browser:
		view_vtk(outfname)

	if not structured_grid_out:
		return

	# case 2: grid = xyz points, scalar data = z
	# SLOW, but can be used with most filters & modules
	# grid ("dataset") as StructuredGrid(dimensions, set of 3-seq)

	zfactor = 1.0
	# zfactor = xyspacing[0] * nx / (max(z1) - min(z1)) # scale z to xspan

	xyz = []
	for iy in range(ny):
		y = xyorigin[1] + xyspacing[1] * iy
		for ix in range(nx):
			x = xyorigin[0] + xyspacing[0] * ix
			xyz.append((x, y, zarray[ix, iy] * zfactor))

	grid = pyvtk.StructuredGrid((nx, ny, 1), xyz)
	if comment:
		data = pyvtk.VtkData(grid, comment, point_data)
	else:
		data = pyvtk.VtkData(grid, point_data)
	outfname = outfbody + "_sg.vtk"
	data.tofile(outfname)
	return

# Open-DX general description file format
dxgenform = """file = %s
grid = %d x %d x %d
format = ascii
interleaving = record
majority = row
field = field0
structure = scalar
type = float
dependency = positions
positions = regular, regular, regular, %g, %g, %g, %g, %g, %g

end
"""

def zarray2dx(zarray, xyorigin, xyspacing, outfbody):
	"""dump z[ix, iy] data to Open-DX file"""
	outfbody, ext = os.path.splitext(outfbody)
	outfname = outfbody + ".dx"

	# write z as simple general data
	outf = open(outfname, 'w')
	for z in zarray.flat:
		outf.write("%g\n" % z)
	outf.close()

	# x, y must be regular mesh (no check)
	nx, ny = zarray.shape
	points = (nx, ny, 1)
	origin = (xyorigin[0], xyorigin[1], 0.0)
	spacing = (xyspacing[0], xyspacing[1], 1.0) # must be positive

	# write a general data descriptor
	outfbody, ext = os.path.splitext(outfname)
	outfname_gen = outfbody + ".general"
	outf = open(outfname_gen, 'w')
	# outfname_unix = string.replace(os.path.abspath(outfname), "\\", "/")
	outfname_unix = string.replace(outfname, "\\", "/")
	outf.write(dxgenform % tuple(flatlist((outfname_unix, 
	points, zip(origin, spacing)))))
	# "form % ()" must be tuple
	outf.close()
	return

def get_spacing(xdata):
	if len(xdata) <= 1: return 1.0
	tolerance = 0.1
	xd1 = xdata[1:]  # array (1,) copy x1, x2, ..., x(n-1)
	xd2 = xdata[:-1] # array (1,) copy x0, x1, ..., x(n-2)
	xdiff = xd1 - xd2
	xdmin, xdmax = min(xdiff), max(xdiff)
	xdd = xdmax - xdmin
	xspacing = (xdmin + xdmax) * 0.5
	assert xdd < xspacing * tolerance, \
	"grid not equally spaced!  spacing = %g, variance = %g > %g" % (xspacing, xdd, 
	xspacing * tolerance)
	return xspacing


if __name__ == "__main__":

	import myutils as M

	# assert argc >= 2, "Usage: python %s dir [dir2 ...]" % sys.argv[0]
	# comline = string.join(["python"] + sys.argv)
	comline = string.join(sys.argv)
	sys.stderr.write("working dir = %s\nscript  dir = %s\n" % (os.path.abspath(os.getcwd()), 
	sys.path[0]))

	argc = len(sys.argv)
	assert argc >= 3, "Usage: python %s a*.dat [..] out.vtk" % sys.argv[0]

	out_dir = "xy2vtk" # output dir
	nygap = 5 # gap between spectra

	M.confirm_mkdir(out_dir)
	logfname = timestr() + ".log"
	logf = open(os.path.join(out_dir, logfname), "w")
	logf.write("\n" + comline + "\n")

	outfname = sys.argv.pop()
	files = []
	for s in sys.argv[1:]:
		files = files + find_files(s)
	if len(files) == 0:
		s = "no input file"
		logf.write(s + "\n")
		sys.exit(s)

	ydlist = []
	nfiles = len(files)
	files.sort()
	for nf, f in enumerate(files):
		s = "%d/%d: input %s" % (nf + 1, nfiles, f)
		print s
		logf.write(s + "\n")
		xydata = read_data(f)
		xd, yd = xydata[:, 0], xydata[:, 1]
		if nf == 0:
			xd0 = xd # caution: reference (pointer) copy
			xspacing = get_spacing(xd0)
			ny = len(yd)
			ydzeros = zeros((ny,), Float)
		else:
			if xd != xd0:
				sys.exit("xd mismatch: %s & %s" % 
				(files[0], f))
		# ydlist.append(yd) # just append
		for i in range(nygap): # gap between spectra
			ydlist.append(ydzeros)
		ydlist.append(yd)
		ydlist.append(yd)
		for i in range(nygap):
			ydlist.append(ydzeros)

	nydlist = len(ydlist)
	zarray = N.array(ydlist) # zarray.shape (nydlist, ny)
	zarray = N.transpose(zarray, (1, 0)) # zarray.shape (ny, nydlist)

	# convert upper-left origin y-down to lower-left origin y-up
	# zarray = zarray[:, ::-1] # reverse y-axis

	# y-spacing is arbitrary; scaled for graphic convenience
	yspacing = (max(xd0) - min(xd0)) / nydlist

	xyorigin = (xd0[0], 0.0)
	xyspacing = (xspacing, yspacing)

	zarray2vtk(zarray, xyorigin, xyspacing, os.path.join(out_dir, 
	outfname), comline)
	logf.close()

# end of file

