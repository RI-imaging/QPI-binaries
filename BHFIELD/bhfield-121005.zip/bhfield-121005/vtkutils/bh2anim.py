# # -*- coding: cp932 -*-
# read bhfield V_Ereim.dat and create paraview 3D animation (snapshots) of Eabs(t)

# To Do:
# fixed scale?
# use vtk time series & paraview animation support?

pvpython = r"C:\Program Files (x86)\ParaView 3.14.1\bin\pvpython.exe"


if __name__ == "__main__":

	import sys, os, string, getopt, math, subprocess
	import numpy as N
	import xy2vtk, xyz2vtk

	# comline = string.join(["python"] + sys.argv)
	comline = string.join(sys.argv)
	sys.stderr.write("working dir = %s\nscript  dir = %s\n" % (os.path.abspath(os.getcwd()), 
	sys.path[0]))

	usage = "Usage: python %s [--nperiod=10] [--npercycle=8] [--angles=80,-115,20,-25,80,45] " \
	"V_Ereim.dat" % sys.argv[0]
	try:
		opts, args = getopt.getopt(sys.argv[1:], "p:c:a:", ["nperiod=", "npercycle=", 
		"angles="])
	except getopt.GetoptError:
		print usage
		sys.exit(2)

	nperiod, npercycle, angles = 10, 8, "80,-115,20,-25,80,45" # default
	for o, a in opts:
		if o in ("-p", "--nperiod"):
			nperiod = int(a)
		if o in ("-c", "--npercycle"):
			npercycle = int(a)
		if o in ("-a", "--angles"):
			angles = a

	argc = len(args)
	assert argc == 1, usage
	fnin = args[0]

	# path angles [(theta, phi), ...]
	imax = nperiod * npercycle
	angles = map(float, angles.split(','))
	th, ph = angles[::2], angles[1::2]
	nangles = min(map(len, (th, ph)))
	ieach = int(imax / (nangles - 1))
	assert ieach > 1, "Too few periods (or too many angles)"
	apath = []
	for i in range(imax):
		ia, im = divmod(i, ieach)
		if ia < nangles - 1:
			t = th[ia] + (th[ia + 1] - th[ia]) * im / float(ieach)
			p = ph[ia] + (ph[ia + 1] - ph[ia]) * im / float(ieach)
		else:
			t, p = th[-1], ph[-1]
		apath.append((t, p))
	# print "angle path", apath

	# pack into vtk, then extract arrays
	# To Do: direct x, y, z arrays easier?

	dataobj = xyz2vtk.xyz2vtk(fnin, "xyzv(E-real)v(E-imag)", save=False)
	ds = dataobj.structure
	dim, ori, spa = ds.dimensions, ds.origin, ds.spacing # 3-tuples each

	pd = dataobj.point_data
	ere, eim = pd.data[0].vectors, pd.data[1].vectors # list of 3-vectors
	# print "data points:", len(ere), " = ", dim[0] * dim[1] * dim[2]

	# numpy trials 'n errors
	# zall = N.array(ere + eim).ravel() # flatten
	# zabs = N.sqrt(zall**2) # or (zall*zall); product * operates elementwise in NumPy arrays
	# zabs = map(lambda x: math.sqrt(x * x), zall)

	ere, eim = map(N.array, (ere, eim))

	# get Eabs span for fixed scale -> needs hack in paraview script; forget it for now
	# Born & Wolf p.36: polarization ellipse
	p2 = (ere**2).sum(axis=-1) # (x**2 + y**2 + z**2)
	q2 = (eim**2).sum(axis=-1)
	pq = (ere*eim).sum(axis=-1)
	a2 = 0.5*(p2 + q2 + N.sqrt((p2 - q2)**2 + 4*pq**2)) # long axis
	a = N.sqrt(a2)
	aspan = [min(a), max(a)]
	# print ere.shape, a.shape # (np, 3) (np,)

	# npercycle = 8 -> cycle in 1/8 steps; 0, 1, ..., 7, 0, ...
	omega = 2.0 * math.pi / npercycle # rather arbitrary (not real freq of light!)

	# BH14: time-harmonic field
	# Ec = (Ere + i Eim) * exp(-iwt); E = Ere cos(wt) + Eim * sin(wt)

	vtk2pv = os.path.join(sys.path[0], "vtk2pv.pv.py")
	for i in range(imax):
		t = float(i)
		et = ere * math.cos(omega * t) + eim * math.sin(omega * t)
		eabs = N.sqrt((et**2).sum(axis=-1))
		# eabs = math.sqrt(et[0] * et[0] + et[1] * et[1] + et[2] * et[2])
		# print et.shape, eabs.shape # (np, 3) (np, )

		# eabs = eabs.clip(min=aspan[0], max=aspan[1]) # NG

		ftempbody = "ftemp-%05d" % i
		ftempvtk = ftempbody + "_sp.vtk"
		ftemppvs = ftempbody + "_sp_Eabs.pv.py"
		vtk = xy2vtk.fields2vtk(dim, ori, spa, [eabs], ["Eabs"], ftempbody, add_vnorm=False)

		# move camera: theta & phi in degrees
		# theta = 0 -> view down from above; 90 -> side view
		# phi = 0 -> +x near to far; +y down to up; +z left to right
		# theta = theta_min + (theta_max - theta_min) * t / (imax - 1)
		# phi = phi_min + (phi_max - phi_min) * t / (imax - 1)
		theta, phi = apath[i]
		elevation = 90.0 - theta
		azimuth = -90.0 + phi

		s = "\"%s\" \"%s\" --glyph_sf=0.1 --legends=x;y;z --elevation=%g --azimuth=%g \"%s\"" % (
		pvpython, vtk2pv, elevation, azimuth, ftempvtk)

		sys.stderr.write(s + '\n')
		# os.system(s) # obsolete; NG for quotation marks!
		subprocess.call(s)

		os.remove(ftempvtk)
		os.remove(ftemppvs)

	sys.stderr.write("done: %d snapshots\n" % imax)

# end of file

