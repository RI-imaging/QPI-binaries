#!/usr/bin/python
# # -*- coding: cp932 -*-
# convert xyz to vtk data for mayavi or paraview
# python xyz2vtk.py "xyzv(E-real)s(|Ec|^2)d" [xyz_*.dat]
# data format: x y Z\n ... (scalar Z on xy grids)
#           or x y z Vx Vy Vz [Wx Wy Wz ...] z1 [z2...]\n ... (vector & scalar fields on xyz)
# specifier: xy[z] = grid, v = vector field (3), s = scalar field (1), d = dummy (skip)

# requires: pyvtk
# to do: use tvtk?

def uniq(list):
	"""return the list of unique items."""
	ans = []
	for x in list:
		if x in ans: continue
		ans.append(x)
	return ans

def recursive_map(func, data):
	"""recursive map on nested list"""
	# [not hasattr(x, "__iter__") and func(x) or recursive_map(func, x) for x in data]
	ans = []
	for x in data:
		if not hasattr(x, "__iter__"):
			xnew = func(x)
		else:
			xnew = recursive_map(func, x)
		ans.append(xnew)
	return ans

def recursive_reduce(func, data):
	"""recursive reduce on nested list"""
	if data is None: return None
	if type(data) == tuple: data = list(data)
	if type(data) == dict: data = list(data.values())
	new = []
	for d in data:
		if type(d) == tuple or type(d) == list:
			dnew = recursive_reduce(func, d)
		elif type(d) == dict:
			dnew = recursive_reduce(func, d.values())
		else:
			dnew = d
		new.append(dnew)
	return reduce(func, new)

def normalize_field(field, name, threshold=9.99e+37):
	"""normalize field (or nested list of fields by a common factor) if threshold is exceeded
	   vtk truncates at vtkDataArray.GetDataTypeMax() (=1.0e+38)
	   field = scalar x[] or list (vector [x[], y[], z[]] etc) or nested list
	   return (normalized field, nfactor, comment) if exceeding limit, (field, 1.0, "") otherwise
	"""
	import sys, types

	fmax = recursive_reduce(lambda x, y: max(abs(x), abs(y)), field)
	sys.stderr.write("%s: max(abs) = %g\n" % (name, fmax))
	if fmax < threshold: return (field, 1.0, "")

	comment = "[normalized by %g]" % fmax
	sys.stderr.write("!!!!! Data exceed vtk's limit !!!!! %s %s\n" % (name, comment))

	fnew = recursive_map(lambda x: (x / fmax), field)
	return (fnew, fmax, comment)

def xyz2vtk(infnames, fields_names, comment="", save=True):
	"""extract data and convert to vtk via xy2vtk.fields2vtk
	   infnames = fname or [fname1, fname2, ...]
	   fields_names = field specifier e.g. "xyzv(E-real)s(|Ec|^2)d"
	   return vtkdata or [vtkdata1, vtkdata2, ...]
	"""

	import sys, os, string, types, re
	import numpy as N
	import pyvtk
	import myutils as M, xy2vtk

	grid = re.search(r"^[xyz]+", fields_names).group(0) # xy, xz, yz, xyz, etc
	fields_names = fields_names[len(grid):] # v()...
	fields = re.sub(r"\([^\(\)]*\)", "", fields_names) # v(v-name)s(s-name)d -> vsd
	names = re.findall(r"(?<=\()[^\(\)]*(?=\))", fields_names) # -> [v-name, s-name]

	if isinstance(infnames, types.StringTypes): infnames = [infnames]

	vtks = []
	for fname in infnames:
		sys.stderr.write("input:  %s\n" % fname)
		infbody, ext = os.path.splitext(fname)

		xd = M.read_data(fname) # [[x1, y1, z1..], ...]
		xyz = zip(*xd) # transpose [[x1, x2, ..], ..]

		# pick up xyz axes
		xa, ya, za = [0.0], [0.0], [0.0] # default
		for g in grid:
			if g == "x":
				xa = xyz.pop(0)
			elif g == "y":
				ya = xyz.pop(0)
			else:
				za = xyz.pop(0)

		# idiots: kuso numpy forces float to default type = numpy.float64
		# causing pyvtk error; only "dtype=object" sets type = float
		xuniq, yuniq, zuniq = map(lambda a: N.array(uniq(a), dtype=object), 
		(xa, ya, za))
		nx, ny, nz = map(len, (xuniq, yuniq, zuniq))
		assert nx * ny * nz == len(xd), "nx(%d) * ny(%d) * nz(%d) != nd(%d)" % (
		nx, ny, nz, len(xd))
		xsp, ysp, zsp = map(xy2vtk.get_spacing, (xuniq, yuniq, zuniq))

		# pick up fields
		data = []
		for fld in fields:
			if fld == "d": # dummy, skip
				xyz.pop(0)
				continue
			elif fld == "s": # scalar field
				f = xyz.pop(0)
			elif fld == "v": # vector field
				f = [xyz.pop(0), xyz.pop(0), xyz.pop(0)]
			else:
				sys.exit("field(%s) unsupported" % fld)
			data.append(f)

		# data = [s[], ..., [vx[], vy[], vz[]], ...]
		# normalize by a common factor if necessary
		data, nfactor, scomment = normalize_field(data, string.join(names)) # nfactor unused

		# transpose etc
		newdata = []
		for f in data:
			if isinstance(f[0], list) or isinstance(f[0], tuple): # vector
				f = zip(*f) # transpose: [[Vx, Vy, Vz], ...]

			# if z changes first, flip to x (or y) changes first
			if (nx > 1 and xa[0] == xa[1]) or (nx == 1 and ny > 1 and ya[0] == ya[1]):
				new = []
				for iz in range(nz):
					for iy in range(ny):
						new += f[(iy * nz + iz)::(ny * nz)] # slice step
						# for ix in range(nx):
						# 	i = (ix * ny + iy) * nz + iz
						# 	new.append(f[i])
				f = new
				sys.stderr.write("transposed to x-runs-first\n")

			newdata.append(f)

		outnames = [names[i] + scomment for i in range(len(names))]

		points = (nx, ny, nz)
		origins = (xa[0], ya[0], za[0])
		spacings = (xsp, ysp, zsp)

		if save:
			outfbody = infbody
			# outfname = infbody + ".vtk"
			# sys.stderr.write("output: %s\n" % outfname)
		else:
			outfbody = None
		vtk = xy2vtk.fields2vtk(points, origins, spacings, 
		newdata, outnames, outfbody, comment=comment, add_vnorm=False)
		vtks.append(vtk)

	if len(vtks) == 1: vtks = vtks[0]
	return vtks


if __name__ == "__main__":

	import sys, os, string
	import myutils as M

	# assert argc >= 2, "Usage: python %s dir [dir2 ...]" % sys.argv[0]
	# comline = string.join(["python"] + sys.argv)
	comline = string.join(sys.argv)
	sys.stderr.write("working dir = %s\nscript  dir = %s\n" % (os.path.abspath(os.getcwd()), 
	sys.path[0]))

	argc = len(sys.argv)
	assert argc == 2 or argc == 3, \
	"usage: python %s \"xyzv(v-name)s(s-name)d\" [xyz*.dat]" % sys.argv[0]

	fields_names = sys.argv[1]
	if argc == 2:
		infnames = M.find_files("*.dat")
		# infnames = M.find_all_files("*.dat") # subdir too
	else:
		infnames = M.find_files(sys.argv[2]) # allow wildcards

	xyz2vtk(infnames, fields_names, comment=comline)

# end of file

