#!/usr/bin/python
# # -*- coding: cp932 -*-
# convert vtk to paraview script/snapshot
# "C:\Program Files (x86)\ParaView 3.10.1\bin\pvpython" vtk2pv.pv.py [data.vtk]

# requires: paraview.simple, pvpython

import os, sys, math, re
# import numpy as N # NG; try not to use it
import paraview.simple as PV

def vtk_info(vtkfname):
	"""get vtk info"""

	# dir(a) useless, does not show all; try help(a) then google vtkPVArrayInformation etc (kuso)

	reader = PV.OpenDataFile(vtkfname)
	reader.UpdatePipeline() # needed!
	di = reader.GetDataInformation() # vtkPVDataInformation wrapper
	dcname = di.GetDataClassName() # 'vtkImageData'
	bo = di.GetBounds() # (-0.2, 0.2, 0.0, 0.0, -0.2, 0.2)
	ex = di.GetExtent() # (0, 10, 0, 0, 0, 10)
	np = di.GetNumberOfPoints() # 121L

	assert dcname == 'vtkImageData' # tentative
	nx, ny, nz = map(lambda x: int(x) + 1, (ex[1] - ex[0], ex[3] - ex[2], ex[5] - ex[4]))
	assert np == nx * ny * nz

	pd = reader.PointData
	# datanames = pd.keys() # ['abs[Ec]^2']
	# data = pd[dataname] # Array; vtkPVArrayInformation wrapper
	# name = data.Name # 'abs[Ec]^2'
	# datarange = data.GetRange() # (0.3, 73.4); component=0
	# dtrange = [0.0, 0.0]; data.GetDataTypeRange(dtrange); silly

	flist = []
	for k, v in pd.items(): # ('E-major', Array)
		dim = v.GetNumberOfComponents()
		flist.append((k, dim)) # ('E-major', 3)
		vtk_rangecheck(v)

	info = (dcname, bo, ex, (nx, ny, nz), flist)
	return info

def vtk_rangecheck(ai):
	"""range overflow check
	ai = Array; vtkPVArrayInformation wrapper
	caution: vtk data truncated at 1.0E+38 ; Oooooooppppsss!!!
	print scalars.range -> (0.0, 1.#INF)
	print scalars.data_type_min, scalars.data_type_max -> -9.99999968029e+037 9.99999968029e+037
	"""
	if ai is None: return

	dtrange = [0.0, 0.0]
	ai.GetDataTypeRange(dtrange) # silly; [-9.999999680285692e+37, 9.999999680285692e+37]
	dtmin, dtmax = dtrange

	name, dim  = ai.Name, ai.GetNumberOfComponents()
	for i in range(dim):
		dmin, dmax = ai.GetRange(i) # 2-tuple
		assert dtmin < dmin and dmax < dtmax, \
		"vtk_rangecheck error! data %s[%d] (%g %g) truncated within (%g %g)" % (
		name, i, dmin, dmax, dtmin, dtmax)

	return

def vtk2pv(vtkfname, legends = "x;y;z", glyph_sf = 0.1, elevation = 30, azimuth = -115):
	"""
	convert vtk file to paraview scripts that can be used for interactive viewing and snapshots.
	vtkfname = vtk filename
	legends = x, y, z legends separated by ';'
	glyph_sf = glyph scale factor (relative to bound span max)
	elevation, azimuth = camera angles

	To Do:
	xyz_scaling = scale x, y, or z-grid span to 1
	show_lut = show look-up table
	use_vector = False, data_idx = 0, xyz_scaling = (True, True, True), 
	show_lut = False, warp_by_vnorm = True, 
	"""

	pnvtk = os.path.abspath(vtkfname) # need full path in paraview python shell (silly)
	basedir, fnvtk = os.path.split(pnvtk)

	fnbody = os.path.splitext(fnvtk)[0]

	dirscr = sys.path[0] # script dir
	dirtmp = os.path.join(dirscr, "pv_templates")

	dcname, bo, ex, np, flist = vtk_info(vtkfname)
	nx, ny, nz = np

	sys.stderr.write("bounds = %s, extents = %s\nfield list = %s\n" % (bo, ex, flist))

	if nx * ny * nz == max((nx, ny, nz)): # 1D data
		ndim = 1
		sys.stderr.write("1D data: no action\n")
		return # no action
	elif nx == 1 or ny == 1 or nz == 1: # 2D data
		ndim = 2
		fntmp = "2d_warp.pv.py"
	else:
		ndim = 3
		fntmp = "3d.pv.py"

	fntmp = os.path.join(dirtmp, fntmp)
	for dname, dim in flist:
		if dim != 1 and dim != 3: continue
		dname_allowed = dname.replace("/", "_over_") # NG for filename
		fnscr = "%s_%s.pv.py" % (fnbody, dname_allowed)
		argdic = {}
		argdic["base_dir"] = basedir # needs full path in script
		argdic["fn_data"] = fnvtk
		argdic["fn_image"] = "%s_%s.png" % (fnbody, dname_allowed)
		argdic["data_name"] = dname

		argdic["legends"] = legends # "x;y;z"
		argdic["glyph_sfactor"] = glyph_sf

		argdic["elevation"] = elevation
		argdic["azimuth"] = azimuth

		template2script(fntmp, fnscr, argdic)
		os.system('pvpython "%s"' % fnscr) # take snapshot

	return

def template2script(fn_template, fn_script, argdic):
	"""generate script from template by setting args (key = r"value" pairs)
	argdic = {key: value, ...}
	"""

	ftmp = open(fn_template, 'r')
	buf = ftmp.read()
	ftmp.close()

	dummy = "ARE YOU DUMMY OR WHAT" # trick to avoid filename/regex confusion
	for k, v in argdic.items():
		buf, ns = re.subn(r"(?<!# )%s *= *.+\n" % k, r'%s = r"%s"\n' % (k, dummy), buf)
		assert ns > 0, "key(%s) not found in %s" % (k, fn_template)
		buf = buf.replace(dummy, str(v))

	fscr = open(fn_script, 'w')
	fscr.write(buf)
	fscr.close()
	return

def find_files(key, dirname = ".", isregex = False):
	"""Find files; taken from myutils"""
	if not isregex:
		dir_in_key = os.path.dirname(key) # if key has dir, attach it in results
		dirname, key = os.path.split(os.path.join(dirname, key)) # in case key contains dir
	else:
		dir_in_key = "" # if dirname is given, it is not attached in results
	files = [f for f in os.listdir(dirname) if os.path.isfile(
	os.path.join(dirname, f))] # isfile() needs path
	# files = filter(lambda s: os.path.isfile(os.path.join(dirname, s), 
	# os.listdir(dirname))
	if key == "": # return all files
		ans = files
	else:
		if not isregex: # simple string, possibly globbing *. or *.*
			key = "^" + re.sub(r"\\\*", r".*", re.escape(key)) + "$"
			# *.bmp -> .*\.bmp
		# reobj = re.compile("^" + string.lower(key) + "$") # case insensitive
		# ans = filter(lambda s: reobj.search(string.lower(s)), files)
		reobj = re.compile(key)
		ans = filter(lambda s: reobj.search(s), files)
	ans = map(lambda s: os.path.join(dir_in_key, s), ans)
	ans.sort()
	return ans # file name (or path name if key has dir) list (sorted)


if __name__ == "__main__":

	import sys, os, string, getopt
	# import myutils as M

	# assert argc >= 2, "Usage: python %s dir [dir2 ...]" % sys.argv[0]
	# comline = string.join(["python"] + sys.argv)
	comline = string.join(sys.argv)
	sys.stderr.write("working dir = %s\nscript  dir = %s\n" % (os.path.abspath(os.getcwd()), 
	sys.path[0]))

	usage = "Usage: pvpython %s [--glyph_sf=0.1] [--legends=x;y;z] [--elevation=30] "\
	"[--azimuth=-115] [data.vtk ...]" % sys.argv[0]
	try:
		opts, args = getopt.getopt(sys.argv[1:], "l:g:e:a:", ["legends=", "glyph_sf=", "elevation=", 
		"azimuth="])
	except getopt.GetoptError:
		print usage
		sys.exit(2)

	legends, glyph_sf, elevation, azimuth = "x;y;z", 0.1, 30, -115 # default
	for o, a in opts:
		if o in ("-l", "--legends"):
			legends = a
		if o in ("-g", "--glyph_sf"):
			glyph_sf = float(a)
		if o in ("-e", "--elevation"):
			elevation = float(a)
		if o in ("-a", "--azimuth"):
			azimuth = float(a)

	argc = len(args)
	if argc == 0:
		files = find_files("*.vtk")
		files += find_files(r".\vtk\*.vtk")
	else:
		files = args[:]

	for f in files:
		vtk2pv(f, legends=legends, glyph_sf=glyph_sf, elevation=elevation, azimuth=azimuth)

# end of file

