#!/usr/bin/python
# # -*- coding: cp932 -*-

# set basedir of pvpython scripts *.pv.py in current working dir
# we need this 'cause cwd, vtk data dir, and script dir are unavailable in paraview shell

# copied from vtk2pv.pv.py
def template2script(fn_template, fn_script, argdic):
	"""generate script from template by setting args (key = r"value" pairs)
	argdic = {key: value, ...}
	"""
	import re

	ftmp = open(fn_template, 'r')
	buf = ftmp.read()
	ftmp.close()

	dummy = "ARE YOU DUMMY OR WHAT" # trick to avoid filename/regex confusion
	for k, v in argdic.items():
		buf, ns = re.subn(r"(?<!# )%s *= *.+\n" % k, r'%s = r"%s"\n' % (k, dummy), buf)
		assert ns > 0
		buf = buf.replace(dummy, str(v))

	fscr = open(fn_script, 'w')
	fscr.write(buf)
	fscr.close()
	return


if __name__ == "__main__":

	import sys, os, string, shutil
	import myutils as M

	# comline = string.join(["python"] + sys.argv)
	comline = string.join(sys.argv)
	sys.stderr.write("working dir = %s\nscript  dir = %s\n" % (os.path.abspath(os.getcwd()), 
	sys.path[0]))

	argc = len(sys.argv)
	assert argc == 1, "usage: python %s" % sys.argv[0]

	cwd = os.path.abspath(os.getcwd())
	bdir = os.path.join(cwd, r"..\vtk")
	print "base_dir in *.pv.py set to [%s]; fn_image set to blank" % bdir

	argdic = {"base_dir": bdir, "fn_image": ""}
	fntmp = "temp.txt"
	fnames = M.find_files("*.pv.py")
	for f in fnames:
		template2script(f, fntmp, argdic)
		shutil.move(fntmp, f)

	print "...done (%d files)" % len(fnames)

# end of file

