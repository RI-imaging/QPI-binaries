Oct 5, 2012 - bhfield readme.txt

This is a corrected and enhanced version of:

BHFIELD: A Fortran program for the Mie field calculation of a coated sphere, University of Toyama (2008-2012)

which is described in:

H. Suzuki and I-Y. S. Lee: Calculation of the Mie Scattering Field inside and outside a Coated Spherical Particle, Int. J. Phys. Sci., 3, 38-41 (2008; Errata: Int. J. Phys. Sci. 4, 615, 2009).

H. Suzuki and I-Y. S. Lee: Mie Scattering Field inside and near a Coated Sphere: Computation and Biomedical Applications, J. Quant. Spectrosc. Radiat. Transfer, in press (2012).


In this version, serious bugs in the previous code have been fixed (Thanks Nate and Zengbo!).  In addition, extensive checking on round-off errors (debugging version) and computation with arbitrary precision (arprec version) have been incorporated.  

These enhancements are motivated by our observation that Riccati-Bessel functions and scattering coefficients cast a serious round-off problem in the cases of highly absorbing material (e.g. silver) and near-resonance conditions.  It is mainly due to the hyperbolic nature of complex trigonometry, and easily exceeds the limit of standard Fortran precision (COMPLEX*16).  In fact, this issue was already pointed out clearly by Bohren and Huffman (BH p. 484); however, it seems even more critical in computing inner and near-particle fields.  

Such problems can be detected by checking numerical equality of algebraically equivalent expressions (and underflows in numerator/denominator expressions), which is done in our debugging version.  

If it happens, we should turn to arbitrary precision scheme, which is (in principle) free from round-off errors.  An excellent package (ARPREC), available from LBNL (http://crd.lbl.gov/~dhbailey/mpdist/), is used in our arprec version.  The catch is, of course, that the computation slows down significantly; you may prefer the standard version when you are sure that round-off is not an issue.  


Note on the program status:

Important: If, unfortunately, you happen to have a previous version of bhfield (prior to July 2012), please discard it and re-calculate all your results with this new version.  I deeply apologize for your inconvenience.  

We have performed (and are still performing) various tests and comparison with other programs, which are listed below.  The program status should still be considered as beta.  Comparison and testing by users are welcome.  

We also strongly encourage you to check out the paper by Kaiser and Schweiger (1993) [see below].  


Archive contents:

readme-bhfield.txt: this file

src: source codes
	bhfield.f: F77 source
	makefile.txt: makefile for mingw/msys + gfortran + arprec
	bh.bat: windows batch file for automatic vtk & paraview visualization (optional)
	arprec-fix: arprec source fixes
	nk_data: wavelength-dependent optical constants (optional)

test: test-run results

vtkutils: python scripts to generate vtk data (*.vtk), paraview scripts (*.pv.py), and time-harmonic animation.  

windows: precompiled windows executables
	bhfield-std.exe: standard version
	bhfield-std-db.exe: standard version w/debugging info
	bhfield-arp.exe: arprec version
	bhfield-arp-db.exe: arprec version w/debugging info


Assumptions and Conditions in the Theory:

1. Non-absorbing medium (ref_med = real)
2. Nonmagnetic (mu = mu0); no net surface charge (BH p.118)
3. Incident field: monochromatic, plane x-polarized (parallel) wave propagating in +z direction with unit amplitude (E0 = 1)

Tweaks:

At the origin (R = 0) in grid field computation, actually R = small is used to avoid zero-division, but fake XP = YP = ZP = 0 is retained for the convenience of vtk 3D plot.  



Usage:

arprec version:
bhfield-arp[-db] mpdigit wl r_core r_coat n_grid_x xspan_min xspan_max n_grid_y yspan_min yspan_max n_grid_z zspan_min zspan_max case Kreibig [n_med n_core k_core n_coat k_coat (case=other)]

standard version: for bhfield-std & bhfield-std-db, omit mpdigit.  
bhfield-std[-db]         wl r_core r_coat n_grid_x xspan_min xspan_max n_grid_y yspan_min yspan_max n_grid_z zspan_min zspan_max case Kreibig [n_med n_core k_core n_coat k_coat (case=other)]


mpdigit: arprec's number of precision digits; increase it to overcome round-off errors
wl[um]: light wavelength in vacuum
r_core[um] r_coat[um]: core & coat radii
n_grid_x xspan_min[um] xspan_max[um]: number & span of grid points for field computation; x span
n_grid_y yspan_min[um] yspan_max[um]: y span
n_grid_z zspan_min[um] zspan_max[um]: z span
case: nanoshell/liposome/HPC/barber/other
Kreibig: Kreibig mean free path correction for Ag (0.0 - 1.0)
n_med n_core k_core n_coat k_coat (case=other only): refractive indices of medium (real), core & coat (n, k)


If case = other, complex refractive indices (n, k at the particular wavelength) must be specified.  Otherwise (case = nanoshell etc) the medium/core/coat materials are predefined and the n,k values are taken from the data file (Ag_palik.nk etc).  The latter reflects our own interest and is intended for use in our lab, so general users may not find it useful :-)



Examples:

# 100-nm silica sphere with 10-nm thick Ag coating, embedded in water
# arprec 20 digits; illuminated with YAG (1064nm); scan xz plane (21x21, +-200nm)
bhfield-arp-db 20 1.064 0.050 0.060 21 -0.2 0.2 1 0 0 21 -0.2 0.2 other 0 1.3205 1.53413 0 0.565838 7.23262

Output:

bhfield.log: log file containing scattering coeffs etc (as well as definitions of the output fields)
bhdebug.log: extra information (checking roundoff errors etc)

E_0allf.dat: E2 = EFSQ[dimensionless] = (relative) squared amplitude of complex E-field; Ec*(Ec^*) / E0**2
E_1core.dat: E2 inside the core
E_2coat.dat: E2 inside the coating
E_3exte.dat: E2 at the outside of the sphere

U_*.dat: U = UABS[F m-1 s-1] = (relative) absorbed energy per unit volume and time; Ua [W m-3] / E0**2

EU_zax.txt: E2(0,0,z) and U(0,0,z) along z-axis; it may be blank if the grid does not include such points

V_0Eelli.dat: vector electric field; vibration ellipse (major & minor axes), ellipticity, azimuth[deg], p-a angle (phi)[deg], handedness angle[deg] & handedness
V_0Ereim.dat: vector electric field; snapshots [Re (t=0), Im (t=period/4)]

V_0Helli.dat: vector magnetic field; vibration ellipse (major & minor axes), ellipticity, azimuth[deg], p-a angle (phi)[deg], E-&H-phase dif[deg], handedness angle[deg] & handedness
V_0Hreim.dat: vector magnetic field; snapshots [Re (t=0), Im (t=period/4)]

V_0Poynt.dat: Poynting vector <S>, EH angle, optical irradiance (intensity) (norm<S>), I(plane), -div<S> (1st-3rd), UABS & DIVSR

V_1*.dat: vector fields inside the core
V_2*.dat: vector fields inside the coating
V_3*.dat: vector fields at the outside of the sphere

For the definition of vibration ellipses and related quantities, see Bohren & Huffman p.46,50 and Born & Wolf (6th Ed) p.34-35 (Eqs.62,66).  Computation of handedness is tentative (cf. Bohren & Huffman p.45).  

-div<S> (1st-3rd) and DIVSR are computed only if the compile option (-DCHECK_NUMERICAL_POYNTING) is specified; it requires numerical differentiation and makes the loop very slow.  


License: GPL (except for the Bessel routines, which follow the original author's license).  


Recommended procedure:

Use arprec-debugging version (bhfield-arp-db), which runs fairly fast on not-too-old PCs.  Check bhdebug.txt to make sure that you specify enough digits to overcome roundoff errors.  If roundoff errors are not an issue and a fast computation is desirable, you may use standard version; however, it is still recommended to verify that both versions give the same result at least for some representative cases.  



To re-compile the source code (Windows):

1. Install mingw including gfortran (4.6.2 or higher); g77 does not work.  
2. Get arprec source tarball from http://crd-legacy.lbl.gov/~dhbailey/mpdist/ and extract it.  
3. Fix arprec to enable command line options by revising <arprec dir>/fortran/main.cpp; see src/arprec-fix/fortran/main-fixed.cpp in this distro.  
4. In the mingw shell, go to <arprec dir>, and do the usual job to build arprec: 
	./configure
	make
	make install
	make fortran-demo
5. If you encounter the error "fpu.cpp: '_control87' was not declared in this scope", add the following line 
	#include "C:\\MinGW\\include\\float.h"
to <arprec dir>/src/fpu.cpp; see src/arprec-fix/src/fpu-fixed.cpp in this distro.  
6. As 
delivered, max mpdigit (mpipl) is set to 2000 digits; alter it in <arprec dir>/fortran/mp_mod.f if needed.  
7. In the mingw shell, go to <distro dir>/src and do the job:
	make -f makefile.txt
8. makefile.txt also contains fortran grammer checking using ftnchek (optional).  



To use vtk/paraview utilities (windows):

1. Install python 2.7 + numpy.  
2. Get pyvtk tarball from http://cens.ioc.ee/projects/pyvtk/ , extract and install it by 
	python setup.py install
3. Install paraview from http://www.paraview.org/ .
4. Put <distro dir>/vtkutils/* into some place that python can find (PYTHONPATH etc), or register <distro dir>/vtkutils/ via a path file (*.pth) in python's site-package dir.  
5. Edit <distro dir>\src\bh.bat to set the three places correctly:
	set bhdir=<distro dir>\windows
	set pydir=<distro dir>\vtkutils
	set pvdir=C:\Program Files (x86)\ParaView 3.14.1\bin
6. In windows prompt, run the batch file like this: 
	<distro dir>\src\bh "20 1.064 0.050 0.060 11 -0.2 0.2 1 0 0 11 -0.2 0.2 other 0 1.3205 1.53413 0 0.565838 7.23262"
which should generates dat (text data), img (paraview snapshots), pv (paraview scripts) and vtk (vtk data) dirs.  
7. To view 3D visualization interactively, run the *.pv.py script from paraview -> tools -> python shell -> run script.  
8. As paraview's python shell cannot use a relative path (oops!), the generated paraview scripts contain the absolute path for vtk files.  If you move the vtk data and scripts to somewhere else, you have to revise the path in *.pv.py.  To do this, go to the new script dir and run <distro dir>\vtkutils\setpvdir.py.  


Testing and comparison that we have done (or are still in progress): 

1. We have performed (limited) comparison with the Barber-Hill codes for a uniform sphere (S7 and S8), and obtained satisfactory agreements.  

2. Other programs that can analytically compute inner/outer fields of a coated sphere:

(a) T. Kaiser and G. Schweiger, Stable Algorithm for the Computation of Mie Coefficients for Scattered and Transmitted Fields of a Coated Sphere. Computers in Physics 7, 682-6 (1993).  

We do not have their code, but we verified that our program successfully reproduced their results (Note on a typographical error: for Fig. 4 in their paper, the refractive indices of the core and shell should be swapped).  

In the case of the single-layer coating, Kaiser and Schweiger developed a stable algorithm for the field calculation, in which the troublesome direct computation of Bessel functions was replaced with the computation of their ratios by careful rearrangement of the scattering coefficients.  Smart people!  Unfortunately, when we started writing our program, their work had escaped our attention (silly me...).  Since we were unaware of any other workarounds against this issue, we decided to use ARP as a 'brute-force' approach.  

So, here's a good news!  If you like to avoid ARP, you can imprement their algorithm!  :-)

Well, however, there might still be several good points about ARP.  First, the numerical precision can be set so high that even extremely narrow resonance peaks (ripple structures) can be explored and located.  Second, the theoretical formulation can be left intact and thus more transparent.  Third, it can also be used in other cases where it is not immediately obvious if the Kaiser-Schweiger-type rearrangement is possible (e.g., stratified structures, Gaussian beam, etc).  

(b) Guangran Kevin Zhu's Sphere Scattering (Matlab script) which we are testing now.  

3. Comparison with numerical field solvers (DDSCAT, MMP3D/OpenMaX etc) is in progress.  

4. Bessel functions: We use Thompson-Barnett code (1987) now, and are also testing Amos 644 (Netlib) code.  

5. Boundary condition: We check tangential continuity across the border (-DCHECK_TANGENTIAL_CONTINUITY).  

6. Zero-clad check (suggested by Dr. Nate Lawrence): If the coating thickness = 0, the result should have no dependence on n_coat & k_coat.  

7. Core = coat check: if n_core = n_coat & k_core = k_coat, the result should have no dependence on r_core.  

8. BH p.123 (4.83): Qback (x->Inf) -> Reflectance for metallic coating.  

9. Extinction paradox (BH p.107): Qext (x->Inf) -> 2.  


To Do:
* Extend it to the multi-layer problem following Pena & Pal (2009).  



... That's about it.  Enjoy!  

Honoh Suzuki
Department of Chemistry, University of Toyama
honoh@sci.u-toyama.ac.jp

